<?php

sspmod_cdc_Server::processRequest();