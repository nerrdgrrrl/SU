<?php



$this->includeAtTemplateBase('includes/header.php');


echo('<h1>OAuth Client saved</h1>');

echo('<p><a href="registry.php">Go back to OAuth client listing</a></p>');



$this->includeAtTemplateBase('includes/footer.php');

